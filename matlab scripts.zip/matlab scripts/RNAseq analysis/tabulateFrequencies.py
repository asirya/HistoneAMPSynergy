#!/usr/bin/env python
#parses SAM file, filters out unmapped, extracts POS names, bins into genome regions
#
#requires: NC008463AllRegionsaNamed.tdt
#usage: tabulateFrequences.py FILENAME.SAM
#output: FILENAME.COUNTED
#
#Albert Siryaporn
#2015-05-13
#updated 2015-05-22 counts for all genomeregions
#updated 2016-10-06 allows for gaps between genomeregions
#updated 2017-02-28 takes 'NC008463AllRegionsNamedv2.tdt' instead of 'NC008463AllRegionsNamed.tdt'

import re
import sys
import os


list =[]
genomeregions=[]
genomeregionsfile=os.path.dirname(os.path.realpath(__file__)) + '/NC008463AllRegionsNamedv2.tdt'

verbose=0
if len(sys.argv) == 2:
    filename= sys.argv[1]
elif len(sys.argv) == 3:
    filename= sys.argv[1]
    if sys.argv[2] == "-v":
        verbose=1
else:
    print("Usage: tabulateFrequences.py FILENAME.SAM [-v (verbose)]")
    sys.exit(2)

newfilename=re.subn(re.compile('.sam',re.IGNORECASE),'_counted.txt',filename)
if newfilename[1] > 0:
    print "Saving file to",newfilename[0]
    file=open(newfilename[0],'w')
else:
    sys.exit("Filename must have .sam extension")

#open genome regions file
print "Loading genome regions..."
with open(genomeregionsfile) as g:
    for regions in g:
        genomeregions.append(regions)
string='Number of gene/intergenic regions: '+ str(len(genomeregions))+'\n'
print string,
file.write(string)

#open SAM file, parse, sort
print "Opening",filename,"..."
with open(filename) as f:
    for line in f:
        elements=re.split('\t+',line)
        if len(elements) > 3:
            if str.isdigit(elements[1]):
                if int(elements[1]) != 4:
                    list.append(int(elements[3]))
print "Sorting SAM records..."
list.sort()
string='Number of mapped reads: \t\t'+str(len(list))+'\n'
print string,
file.write(string)

#go through each genome region and count # of reads in each region
#delete record in SAM file after done
print "Counting reads in each region..."
for i, line in enumerate(genomeregions):
    #    print "genome region:",i
    count=0;
    firstindex=0;
    lastindex=0;
    delete=0;
    lineelements = re.split('\t+',line)
    elementID=lineelements[0]
    startposition=int(lineelements[1])
    endposition=int(lineelements[2])

    for j, SAMvalue in enumerate(list):
        #print (SAMvalue)
        lastindex=j;
        if  (SAMvalue >= startposition) & (SAMvalue <= endposition):
            count+=1
            delete=1
        elif (SAMvalue > endposition):
            break
        elif (SAMvalue < startposition):
            string='gap between last position and ' + str(startposition) + '. There are gaps in the tdt file.'
            print string
            delete=1;
    if delete==1:
        del list[firstindex:lastindex]
    string=str(elementID) + '\t' + str(startposition) + '\t' + str(endposition) + '\t' + str(count)+'\n'

    if verbose:
        print string,
    file.write(string)

file.close
print "Saved to",newfilename[0],". Counting done."
