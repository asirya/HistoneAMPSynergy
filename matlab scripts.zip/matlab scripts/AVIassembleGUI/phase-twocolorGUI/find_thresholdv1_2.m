%v1.2 add fit in imshow
%add showmasks
%3/26/12

function threshold=find_thresholdv1_1(IMG, particlevariation, s1value, dilate, showmasks)
settings.thresholdstep=100;
settings.thresholdinterval=s1value;
intervalnotfound=1;
threshold=0;
t1=min(min(IMG));
t2=max(max(IMG));
se90 = strel('line', 3, 90); %image dilation kernel (structural element) dilate image using this kernel
se0 = strel('line', 3, 0);

%v1.1 returns threshold value

for j=1:settings.thresholdstep:(t2-t1)
    range=(IMG> (t1+j) & IMG <= t2);
    if showmasks
        imshow(range,'InitialMagnification', 'fit');
        drawnow;
    end    
    
    particles(j)=max(max(bwlabel(range)));
    if j > settings.thresholdinterval && intervalnotfound
        if(particles(j)-particles(j-settings.thresholdinterval))< particlevariation
            intervalnotfound=0;
            if dilate
                range=imdilate(range,[se0 se90]);
            end
            if showmasks
                imshow(range, [0 0 0; 1 0 0]);
                drawnow;
            end
            threshold=t1+j;
            break;
        end
    end
    
end