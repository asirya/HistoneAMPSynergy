%gui version derived from cell_velocity_v.1.43.m
%REQUIRES find_threshold.m edge_sobel.m,fig
%eliminates handles.metricdata.settings.filetype=1,2 and keeps only mode 3
%pctGUI1.0.120420: added ?cross? option for imdilate, added stderr report to var_ report
%pctGUI1.0.120711 - adds counting # of cells above an arbitrary threshold
%pctGUI1.0.120726 - added 'load previous settings' button
%pctGUI1.0.140521 - added handpickmsks, labelparticlenumber
%pctGUI1.0.170921 - modified ptc.m to include cell area
%pctGUI1.0.170925 - modified ptcGUI to display foldersuffix settings when
                    %loading previous settings
%2018-04-25 changes by Henry:
%-removed "settingsexist" method

function varargout = ptcGUI(varargin)
% PTCGUI MATLAB code for ptcGUI.fig
%      PTCGUI, by itself, creates a new PTCGUI or raises the existing
%      singleton*.
%
%      H = PTCGUI returns the handle to a new PTCGUI or the handle to
%      the existing singleton*.
%
%      PTCGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PTCGUI.M with the given input arguments.
%
%      PTCGUI('Property','Value',...) creates a new PTCGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ptcGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ptcGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ptcGUI

% Last Modified by GUIDE v2.5 11-Mar-2019 20:12:16

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ptcGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @ptcGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ptcGUI is made visible.
function ptcGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ptcGUI (see VARARGIN)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%PARAMETERS GROUP 1: CELL MASK detection settings - probably the most frequently-tweaked settings
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
handles.metricdata.settings.version='pctGUI1.0.170921';

%sobel parameters
%handles.metricdata.settings.sobel.threshold=0.0004; %specify sobel threshold sensitivity. default for phase is 0.0075; 0.0017 works for bacteria; 0.0005 works for AX3 40X on BB scope

%threshold interval parameters
%handles.metricdata.settings.thresholdinterval.default=100; %pixel interval over which the change in the number of particles must be less than handles.metricdata.settings.pasrticlevariation.
%handles.metricdata.settings.particlevariation.default=50; %maximum particle number difference over handles.metricdata.settings.threshold interval. probably better not to mess with this.
handles.metricdata.settings.thresholdstep=1; %step size along intensity table. set higher step size for faster mask making. future version will have automatic threshold step sizing
handles.metricdata.settings.autothreshold=0; %1=autothreshold and ignore handles.metricdata.settings.thresholdinterval.default and handles.metricdata.settings.thresholdstep; 0=manual threshold using settings above. doesn't really work

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%PARAMETERS GROUP 2: DATA ANALYSIS settings
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
handles.metricdata.settings.percentile1=0; %average velocity between handles.metricdata.settings.percentile1 and handles.metricdata.settings.percentile2. for example handles.metricdata.settings.percentile1=0, handles.metricdata.settings.percentile2=0.2 will average the 20% smallest (most negative) velocities
handles.metricdata.settings.percentile2=1; %REQUIREMENT: handles.metricdata.settings.percentile1 < handles.metricdata.settings.percentile2
handles.metricdata.settings.numberofframes=1; %number of frames to average (size of frame group)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MISC PARAMETERS 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
handles.metricdata.settings.suffix='_default'; %suffix appended to data variables after analysis is complete
handles.metricdata.settings.se90 = strel('line', 5, 90); %image dilation kernel (structural element) dilate image using this kernel (for sobel)
handles.metricdata.settings.se0 = strel('line', 5, 0);
%structure=[handles.metricdata.settings.se0 handles.metricdata.settings.se90];
%handles.metricdata.structure=strel('disk',3);
%handles.metricdata.settings.disksize=3;

%load previous settings if present. THIS WILL OVERWRITE SETTINGS THAT WERE JUST SET
evalin('base','if exist(''settings'',''var''); settingsexist=1; temp=settings; else; settingsexist=0; temp=[]; end; assignin(''caller'',''settingsexist'',settingsexist)');
%if ~exist('settings')
%elseif isempty(settings)

%REMOVED BY HENRY
%if (settingsexist==0)
%elseif (settingsexist==1)
%     display(settings);
%     if strcmp(handles.metricdata.settings.version,settings.version)
%        loadprevioussettings(hObject,handles,settings);
%     else
%        display('Different settings version detected. Loading defaults...');
%     end
%else    
%end
%END OF CHANGES by Henry

%load files in current directory
handles.metricdata.currentdir=pwd;
%fileinfo=dir(strcat(handles.metricdata.currentdir,'/*.tif'));
fileinfo=dir();
handles.metricdata.files=transpose({fileinfo.name});
set(handles.text4, 'String', handles.metricdata.files);
set(handles.text20,'String', 'Ready');
set(handles.uipanel19, 'SelectedObject', handles.radiobutton1);
handles.metricdata.settings.programmode=1;
handles.output = hObject;
guidata(hObject, handles);
%uiwait();
% UIWAIT makes ptcGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = ptcGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
%clear all; 
%close; use with uiwait in OpenFcn()

%function loadprevioussettings(hObject, eventdata, handles)


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1
input=get(hObject,'Value');
if (input == 1)
    handles.metricdata.settings.thresholdmode=1;
elseif (input == 2)
    handles.metricdata.settings.thresholdmode=2;
elseif (input == 3)
    handles.metricdata.settings.thresholdmode=3;
elseif (input == 4)
    handles.metricdata.settings.thresholdmode=4;
end
display(['thresholdmode: ' num2str(handles.metricdata.settings.thresholdmode)]);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
input=get(hObject,'Value');
handles.metricdata.settings.thresholdmode=input;
%display(['thresholdmode: ' num2str(handles.metricdata.settings.thresholdmode)]);
guidata(hObject, handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in checkbox6.
function checkbox6_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox6
%handles.metricdata.settings.debug=get(hObject,'Value');
handles.metricdata.settings.thresholdvalue.dilate=get(hObject,'Value');
display(['Dilate for threshold: ' num2str(handles.metricdata.settings.thresholdvalue.dilate)]);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function checkbox6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to checkbox6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
handles.metricdata.settings.thresholdvalue.dilate=get(hObject,'Value');
guidata(hObject, handles);

% --- Executes on button press in checkbox1.
function checkbox1_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of checkbox1
handles.metricdata.settings.debug=get(hObject,'Value');
display(['debug: ' num2str(handles.metricdata.settings.debug)]);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function checkbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to checkbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
handles.metricdata.settings.debug=get(hObject,'Value');
guidata(hObject, handles);

% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of checkbox2
handles.metricdata.settings.usegrayscale=get(hObject,'Value');
display(['use grayscale: ' num2str(handles.metricdata.settings.usegrayscale)]);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function checkbox2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
handles.metricdata.settings.usegrayscale=get(hObject,'Value');
guidata(hObject, handles);

% --- Executes on button press in checkbox3.
function checkbox3_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox3
handles.metricdata.settings.savemasks=get(hObject,'Value');
display(['save masks: ' num2str(handles.metricdata.settings.savemasks)]);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function checkbox3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to checkbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
handles.metricdata.settings.savemasks=get(hObject,'Value');
guidata(hObject, handles);

% --- Executes on button press in checkbox4.
function checkbox4_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox4
handles.metricdata.settings.showmasks=get(hObject,'Value');
display(['show masks: ' num2str(handles.metricdata.settings.showmasks)]);
if handles.metricdata.settings.showmasks==0
    set(handles.checkbox19, 'Enable', 'off');
    set(handles.checkbox20, 'Enable', 'off');
else
    set(handles.checkbox19, 'Enable', 'on');
    set(handles.checkbox20, 'Enable', 'on');
end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function checkbox4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to checkbox4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
handles.metricdata.settings.showmasks=get(hObject,'Value');
guidata(hObject, handles);

% --- Executes on button press in checkbox19.
function checkbox19_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.metricdata.settings.handpickmasks=get(hObject,'Value');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function checkbox19_CreateFcn(hObject, eventdata, handles)
% hObject    handle to checkbox19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
handles.metricdata.settings.handpickmasks=get(hObject,'Value');
guidata(hObject, handles);

% --- Executes on button press in checkbox20.
function checkbox20_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.metricdata.settings.labelparticlenumbers=get(hObject,'Value');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function checkbox20_CreateFcn(hObject, eventdata, handles)
% hObject    handle to checkbox20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
handles.metricdata.settings.labelparticlenumbers=get(hObject,'Value');
guidata(hObject, handles);

% --- Executes on button press in checkbox5.
function checkbox5_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox5
handles.metricdata.settings.clearvariables=get(hObject,'Value');
display(['Clear variables: ' num2str(handles.metricdata.settings.clearvariables)]);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function checkbox5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to checkbox5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
handles.metricdata.settings.clearvariables=get(hObject,'Value');
guidata(hObject, handles);


% --- Executes on button press in checkbox7.
function checkbox7_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox7
handles.metricdata.settings.doanalysis=get(hObject,'Value');
display(['Do analysis: ' num2str(handles.metricdata.settings.doanalysis)]);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function checkbox7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to checkbox7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
handles.metricdata.settings.doanalysis=get(hObject,'Value');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function Analyze_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Analyze (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
currentdir=uigetdir(pwd);
cd(currentdir);
if not(currentdir)
    disp('Error: directory not selected.');
else
    handles.metricdata.currentdir=currentdir;
    set(handles.textCurrDir,'String', handles.metricdata.currentdir);
    %fileinfo=dir(strcat(currentdir,'/*.tif'));
    fileinfo=dir();
    handles.metricdata.files=transpose({fileinfo.name});
    if isempty(handles.metricdata.files)
        handles.metricdata.files='No TIF files found';
    end
    set(handles.text4, 'String', handles.metricdata.files);
    guidata(hObject,handles);
end

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%assignin('base', 'settings', handles.metricdata.settings);
close();
%uiresume();

function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double
handles.metricdata.settings.minimumarea=str2double(get(hObject, 'String'));
display(['min cell area: ' num2str(handles.metricdata.settings.minimumarea)]);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
handles.metricdata.settings.minimumarea=str2double(get(hObject, 'String'));
guidata(hObject, handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double
handles.metricdata.settings.maximumarea=str2double(get(hObject, 'String'));
display(['max cell area: ' num2str(handles.metricdata.settings.maximumarea)]);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
handles.metricdata.settings.maximumarea=str2double(get(hObject, 'String'));
guidata(hObject, handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double
handles.metricdata.settings.sobel.threshold=str2double(get(hObject, 'String'));
display(['sobel threshold: ', num2str(handles.metricdata.settings.sobel.threshold)]);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
handles.metricdata.settings.sobel.threshold=str2double(get(hObject, 'String'));
guidata(hObject, handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double
handles.metricdata.settings.thresholdinterval.default=str2double(get(hObject, 'String'));
display(['particle variation interval: ', num2str(handles.metricdata.settings.thresholdinterval.default)]);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
handles.metricdata.settings.thresholdinterval.default=str2double(get(hObject, 'String'));
guidata(hObject, handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double
handles.metricdata.settings.particlevariation.default=str2double(get(hObject, 'String'));
display(['particle variation number: ', num2str(handles.metricdata.settings.particlevariation.default)]);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
handles.metricdata.settings.particlevariation.default=str2double(get(hObject, 'String'));
guidata(hObject, handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function textCurrDir_CreateFcn(hObject, eventdata, handles)
% hObject    handle to textCurrDir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
handles.metricdata.currentdir = pwd;
set(hObject,'String', handles.metricdata.currentdir);
guidata(hObject,handles);


% --- Executes on button press in checkbox8.
function checkbox8_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox8



function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double
handles.metricdata.settings.canny.low=str2double(get(hObject, 'String'));
display(['lower canny: ', num2str(handles.metricdata.settings.canny.low)]);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
handles.metricdata.settings.canny.low=str2double(get(hObject, 'String'));
guidata(hObject, handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit10_Callback(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit10 as text
%        str2double(get(hObject,'String')) returns contents of edit10 as a double
handles.metricdata.settings.canny.high=str2double(get(hObject, 'String'));
display(['upper canny: ', num2str(handles.metricdata.settings.canny.high)]);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
handles.metricdata.settings.canny.high=str2double(get(hObject, 'String'));
guidata(hObject, handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit11_Callback(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit11 as text
%        str2double(get(hObject,'String')) returns contents of edit11 as a double
handles.metricdata.settings.thresholdpixelvalue=str2double(get(hObject, 'String'));
display(['upper canny: ', num2str(handles.metricdata.settings.thresholdpixelvalue)]);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
handles.metricdata.settings.thresholdpixelvalue=str2double(get(hObject, 'String'));
guidata(hObject, handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit12_Callback(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit12 as text
%        str2double(get(hObject,'String')) returns contents of edit12 as a double
handles.metricdata.settings.masksuffix=get(hObject, 'String');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
handles.metricdata.settings.masksuffix=get(hObject, 'String');
guidata(hObject, handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit13 as text
%        str2double(get(hObject,'String')) returns contents of edit13 as a double
handles.metricdata.settings.fluorsuffix1=get(hObject, 'String');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.metricdata.settings.fluorsuffix1=get(hObject, 'String');
guidata(hObject, handles);

function edit14_Callback(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit14 as text
%        str2double(get(hObject,'String')) returns contents of edit14 as a double
handles.metricdata.settings.fluorsuffix2=get(hObject, 'String');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit14_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
handles.metricdata.settings.fluorsuffix2=get(hObject, 'String');
guidata(hObject, handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox9.
function checkbox9_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox9
handles.metricdata.settings.backsub=get(hObject,'Value');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function checkbox9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to checkbox9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
handles.metricdata.settings.backsub=get(hObject,'Value');
guidata(hObject, handles);


% --- Executes on button press in checkbox10.
function checkbox10_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox10
handles.metricdata.settings.invert=get(hObject, 'Value');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function checkbox10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to checkbox10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
handles.metricdata.settings.invert=get(hObject, 'Value');
guidata(hObject, handles);

function edit15_Callback(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit15 as text
%        str2double(get(hObject,'String')) returns contents of edit15 as a double
handles.metricdata.settings.disksize=round(str2double(get(hObject, 'String')));
display(['disk size: ' num2str(handles.metricdata.settings.disksize)]);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit15_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
handles.metricdata.settings.disksize=round(str2double(get(hObject, 'String')));
guidata(hObject, handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2
input=get(hObject,'Value');
if (input == 1)
    handles.metricdata.settings.structuretype='disk';
elseif input == 2
    handles.metricdata.settings.structuretype='line';
else
    handles.metricdata.settings.structuretype='disk';
end
%display(handles.metricdata.settings.structure);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
input=get(hObject,'Value');
if (input == 1)
    handles.metricdata.settings.structuretype='disk';
elseif input == 2
    handles.metricdata.settings.structuretype='line';
else
    handles.metricdata.settings.structuretype='disk';
end
%display(handles.metricdata.settings.structure);
guidata(hObject, handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit17_Callback(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit17 as text
%        str2double(get(hObject,'String')) returns contents of edit17 as a double
handles.metricdata.settings.disksize2=round(str2double(get(hObject, 'String')));
display(['disk size2: ' num2str(handles.metricdata.settings.disksize2)]);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit17_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
handles.metricdata.settings.disksize2=round(str2double(get(hObject, 'String')));
guidata(hObject, handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu4.
function popupmenu4_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu4 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu4
input=get(hObject,'Value');
if (input == 1)
    handles.metricdata.settings.structuretype2='disk';
else
    handles.metricdata.settings.structuretype2='disk';
end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function popupmenu4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
input=get(hObject,'Value');
if (input == 1)
    handles.metricdata.settings.structuretype2='disk';
else
    handles.metricdata.settings.structuretype2='disk';
end
guidata(hObject, handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit18_Callback(hObject, eventdata, handles)
% hObject    handle to edit18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit18 as text
%        str2double(get(hObject,'String')) returns contents of edit18 as a double
handles.metricdata.settings.foldername=get(hObject, 'String');
if isempty(handles.metricdata.settings.foldername);
    handles.metricdata.settings.foldersuffixtype='none';
    set(handles.popupmenu6, 'Value', 1);
    handles.metricdata.settings.foldersuffixstart=1;
    set(handles.edit19, 'String', handles.metricdata.settings.foldersuffixstart);
    handles.metricdata.settings.foldersuffixend=1;
    set(handles.edit20, 'String', handles.metricdata.settings.foldersuffixend);
elseif ~isempty(handles.metricdata.settings.foldername);
    handles.metricdata.settings.foldersuffixtype='number';
    set(handles.popupmenu6, 'Value', 2);
end

guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit18_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
handles.metricdata.settings.foldername=get(hObject, 'String');
guidata(hObject, handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit19_Callback(hObject, eventdata, handles)
% hObject    handle to edit19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit19 as text
%        str2double(get(hObject,'String')) returns contents of edit19 as a double
handles.metricdata.settings.foldersuffixstart=round(str2double(get(hObject, 'String')));
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit19_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
handles.metricdata.settings.foldersuffixstart=round(str2double(get(hObject, 'String')));
guidata(hObject, handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit20_Callback(hObject, eventdata, handles)
% hObject    handle to edit20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit20 as text
%        str2double(get(hObject,'String')) returns contents of edit20 as a double
handles.metricdata.settings.foldersuffixend=round(str2double(get(hObject, 'String')));
if handles.metricdata.settings.foldersuffixend==1
    handles.metricdata.settings.foldersuffixtype='none';
    set(handles.popupmenu6, 'Value', 1);

    handles.metricdata.settings.foldername='';
    set(handles.edit18, 'String', handles.metricdata.settings.foldername);

    handles.metricdata.settings.foldersuffixstart=1;
    set(handles.edit19, 'String', handles.metricdata.settings.foldersuffixstart);
end

guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit20_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
handles.metricdata.settings.foldersuffixend=round(str2double(get(hObject, 'String')));
guidata(hObject, handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in checkbox11.
function checkbox11_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox11
handles.metricdata.settings.imdilate=get(hObject,'Value');
guidata(hObject, handles);

% --- Executes on button press in checkbox12.
function checkbox12_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox12
% --- Executes on button press in checkbox11.
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox11
handles.metricdata.settings.imopen=get(hObject,'Value');
guidata(hObject, handles);

% --- Executes on button press in checkbox13.
function checkbox13_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox13
handles.metricdata.settings.imclose=get(hObject,'Value');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function checkbox11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to checkbox11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
handles.metricdata.settings.imdilate=get(hObject,'Value');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function checkbox12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to checkbox12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
handles.metricdata.settings.imopen=get(hObject,'Value');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function checkbox13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to checkbox13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
handles.metricdata.settings.imclose=get(hObject,'Value');
guidata(hObject, handles);

% --- Executes on selection change in popupmenu6.
function popupmenu6_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu6 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu6
input=get(hObject,'Value');
if (input == 1)
    handles.metricdata.settings.foldersuffixtype='none';
    
    handles.metricdata.settings.foldername='';
    set(handles.edit18, 'String', handles.metricdata.settings.foldername);
    
    handles.metricdata.settings.foldersuffixstart=1;
    set(handles.edit19, 'String', handles.metricdata.settings.foldersuffixstart);
    handles.metricdata.settings.foldersuffixend=1;
    set(handles.edit20, 'String', handles.metricdata.settings.foldersuffixend);
elseif (input == 2)
    handles.metricdata.settings.foldersuffixtype='number';
end
display(['foldersuffix type: ' handles.metricdata.settings.foldersuffixtype]);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function popupmenu6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
input=get(hObject,'Value');
if (input == 1)
    handles.metricdata.settings.foldersuffixtype='none';
elseif (input == 2)
    handles.metricdata.settings.foldersuffixtype='number';
end
guidata(hObject, handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit21_Callback(hObject, eventdata, handles)
% hObject    handle to edit21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit21 as text
%        str2double(get(hObject,'String')) returns contents of edit21 as a double
handles.metricdata.settings.masksuffix2=get(hObject, 'String');
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit21_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
handles.metricdata.settings.masksuffix2=get(hObject, 'String');
guidata(hObject, handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in checkbox14.
function checkbox14_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox14
handles.metricdata.settings.includebelowbackground=get(hObject,'Value');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function checkbox14_CreateFcn(hObject, eventdata, handles)
% hObject    handle to checkbox14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
handles.metricdata.settings.includebelowbackground=get(hObject,'Value');
guidata(hObject, handles);

% --- Executes on button press in checkbox15.
function checkbox15_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of checkbox15
handles.metricdata.settings.autocontrast.on=get(hObject,'Value');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function checkbox15_CreateFcn(hObject, eventdata, handles)
% hObject    handle to checkbox15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
handles.metricdata.settings.autocontrast.on=get(hObject,'Value');
guidata(hObject, handles);

function edit22_Callback(hObject, eventdata, handles)
% hObject    handle to edit22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit22 as text
%        str2double(get(hObject,'String')) returns contents of edit22 as a double
handles.metricdata.settings.arbitrarythreshold=round(str2double(get(hObject, 'String')));
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit22_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
handles.metricdata.settings.arbitrarythreshold=round(str2double(get(hObject, 'String')));
guidata(hObject, handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit23_Callback(hObject, eventdata, handles)
% hObject    handle to edit23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit23 as text
%        str2double(get(hObject,'String')) returns contents of edit23 as a double
handles.metricdata.settings.autocontrast.blurrradius=round(str2double(get(hObject, 'String')));
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit23_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
handles.metricdata.settings.autocontrast.blurrradius=round(str2double(get(hObject, 'String')));
guidata(hObject, handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit24_Callback(hObject, eventdata, handles)
% hObject    handle to edit24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit24 as text
%        str2double(get(hObject,'String')) returns contents of edit24 as a double
handles.metricdata.settings.autocontrast.sigma=round(str2double(get(hObject, 'String')));
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit24_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
handles.metricdata.settings.autocontrast.sigma=round(str2double(get(hObject, 'String')));
guidata(hObject, handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox16.
function checkbox16_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of checkbox16
handles.metricdata.settings.displaycellsizehistogram=get(hObject,'Value');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function checkbox16_CreateFcn(hObject, eventdata, handles)
% hObject    handle to checkbox16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
handles.metricdata.settings.displaycellsizehistogram=get(hObject,'Value');
guidata(hObject, handles);

% --- Executes on button press in checkbox17.
function checkbox17_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of checkbox17
handles.metricdata.settings.displayintensityhistogram=get(hObject,'Value');
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function checkbox17_CreateFcn(hObject, eventdata, handles)
% hObject    handle to checkbox17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
handles.metricdata.settings.displayintensityhistogram=get(hObject,'Value');
guidata(hObject,handles);

function loadprevioussettings(hObject,handles,settings)
handles.metricdata.settings=settings;
%set(handles.checkbox2, 'Value', handles.metricdata.settings.usegrayscale);
set(handles.checkbox3, 'Value', handles.metricdata.settings.savemasks);
set(handles.checkbox4, 'Value', handles.metricdata.settings.showmasks);
set(handles.checkbox19, 'Value', handles.metricdata.settings.handpickmasks);
set(handles.checkbox20, 'Value', handles.metricdata.settings.labelparticlenumbers);
if handles.metricdata.settings.showmasks==0
    set(handles.checkbox19, 'Enable', 'off');
    set(handles.checkbox20, 'Enable', 'off');
else
    set(handles.checkbox19, 'Enable', 'on');
    set(handles.checkbox20, 'Enable', 'on');
end
set(handles.edit12, 'String', handles.metricdata.settings.masksuffix);
set(handles.edit21, 'String', handles.metricdata.settings.masksuffix2);
set(handles.edit13, 'String', handles.metricdata.settings.fluorsuffix1);
set(handles.edit14, 'String', handles.metricdata.settings.fluorsuffix2);
%set(handles.checkbox1, 'Value', handles.metricdata.settings.debug);
%set(handles.checkbox5, 'Value', handles.metricdata.settings.clearvariables);
%set(handles.checkbox7, 'Value', handles.metricdata.settings.doanalysis);
set(handles.popupmenu1, 'Value', (handles.metricdata.settings.thresholdmode));
set(handles.edit3, 'String', handles.metricdata.settings.thresholdinterval.default);
set(handles.edit4, 'String', handles.metricdata.settings.particlevariation.default);
set(handles.checkbox6, 'Value', handles.metricdata.settings.thresholdvalue.dilate);
set(handles.edit9, 'String', handles.metricdata.settings.canny.low)
set(handles.edit10, 'String', handles.metricdata.settings.canny.high)
set(handles.edit2, 'String', handles.metricdata.settings.sobel.threshold);
set(handles.edit11, 'String', handles.metricdata.settings.thresholdpixelvalue);
set(handles.edit5, 'String', handles.metricdata.settings.minimumarea);
set(handles.edit6, 'String', handles.metricdata.settings.maximumarea);
set(handles.checkbox9, 'Value', handles.metricdata.settings.backsub);
set(handles.checkbox11, 'Value', handles.metricdata.settings.imdilate);
set(handles.checkbox12, 'Value', handles.metricdata.settings.imopen);
set(handles.checkbox13, 'Value', handles.metricdata.settings.imclose);
set(handles.checkbox14, 'Value', handles.metricdata.settings.includebelowbackground);
set(handles.checkbox15, 'Value', handles.metricdata.settings.autocontrast.on);
set(handles.checkbox16, 'Value', handles.metricdata.settings.displaycellsizehistogram);
set(handles.checkbox17, 'Value', handles.metricdata.settings.displayintensityhistogram);
set(handles.edit23, 'String', handles.metricdata.settings.autocontrast.blurrradius);
set(handles.edit24, 'String', handles.metricdata.settings.autocontrast.sigma);
set(handles.edit15, 'String', handles.metricdata.settings.disksize);
set(handles.edit17, 'String', handles.metricdata.settings.disksize2);
set(handles.edit22, 'String', handles.metricdata.settings.arbitrarythreshold);

if strcmp(handles.metricdata.settings.structuretype,'disk')
    set(handles.popupmenu2, 'Value', 1);
elseif strcmp(handles.metricdata.settings.structuretype,'line')
    set(handles.popupmenu2, 'Value', 2);
else
    set(handles.popupmenu2, 'Value', 1);
end

if strcmp(handles.metricdata.settings.structuretype2,'disk')
    set(handles.popupmenu4, 'Value', 1);
else
    set(handles.popupmenu4, 'Value', 1);
end

%if strcmp(handles.metricdata.settings.foldersuffixtype,'number')
%    set(handles.popupmenu6, 'Value', 2);
%else
%    set(handles.popupmenu6, 'Value', 1);
%end

%set(handles.edit18, 'String', handles.metricdata.settings.foldername);
%set(handles.edit19, 'String', handles.metricdata.settings.foldersuffixstart);
%set(handles.edit20, 'String', handles.metricdata.settings.foldersuffixend);

handles.metricdata.settings.foldername='';
handles.metricdata.settings.foldersuffixtype='none';
handles.metricdata.settings.foldersuffixstart=1;
handles.metricdata.settings.foldersuffixend=1;

if strcmp(handles.metricdata.settings.foldersuffixtype, 'none')
    output=1;
elseif strcmp(handles.metricdata.settings.foldersuffixtype, 'number')
    output=2;
end

set(handles.popupmenu6, 'Value', output);
set(handles.edit18, 'String', handles.metricdata.settings.foldername);
set(handles.edit19, 'String', handles.metricdata.settings.foldersuffixstart);
set(handles.edit20, 'String', handles.metricdata.settings.foldersuffixend);

if handles.metricdata.settings.programmode==1
    set(handles.uipanel19, 'SelectedObject', handles.radiobutton1);
elseif handles.metricdata.settings.programmode==2
    set(handles.uipanel19, 'SelectedObject', handles.radiobutton2);
elseif handles.metricdata.settings.programmode==3
    set(handles.uipanel19, 'SelectedObject', handles.radiobutton3);
elseif handles.metricdata.settings.programmode==4
    set(handles.uipanel19, 'SelectedObject', handles.radiobutton4);
elseif handles.metricdata.settings.programmode==5
    set(handles.uipanel19, 'SelectedObject', handles.radiobutton5);
else
    display(['Program mode not found. Setting normal mode.']);
    set(handles.uipanel19, 'SelectedObject', handles.radiobutton1);
end

display('Previous settings loaded...');
guidata(hObject, handles);


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[fileName pathName]=uigetfile('*.MAT,*.mat');
loaded = load([pathName fileName], 'settings');
%display(loaded.settings);
loadprevioussettings(hObject,handles,loaded.settings);

% --- Executes during object creation, after setting all properties.
function pushbutton4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% --- Executes during object creation, after setting all properties.
function uipanel19_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uipanel19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% --------------------------------------------------------------------
function uipanel19_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to uipanel19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes when selected object is changed in uipanel19.
function uipanel19_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in uipanel19 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)
if (hObject == handles.radiobutton1)
    handles.metricdata.settings.programmode=1;
elseif (hObject == handles.radiobutton2)
    handles.metricdata.settings.programmode=2;
elseif (hObject == handles.radiobutton3)
    handles.metricdata.settings.programmode=3;
elseif (hObject == handles.radiobutton4)
    handles.metricdata.settings.programmode=4;
elseif (hObject == handles.radiobutton5)
    handles.metricdata.settings.programmode=5;
end
guidata(hObject,handles)
display(['program mode: ' num2str(handles.metricdata.settings.programmode)]);


% --- Executes on button press in Analyze.
function Analyze_Callback(hObject, eventdata, handles)
% hObject    handle to Analyze (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.text20,'String','Processing...');
if isempty(handles.metricdata.files)
    error('No avi files found. Exiting...');
end

%from ptc.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
handles.metricdata.settings.usemask=0;
handles.metricdata.settings.splitTIFFs=0;

%###########################################
% EDIT FILE LOCATION, ETC. PARAMETERS HERE #
%###########################################
handles.metricdata.settings.connector='-';

%handles.metricdata.settings.foldersuffixtype='number';  %enter the folder suffice type: 'number', 'letter', 'LETTER' or 'none'.
handles.metricdata.settings.foldersuffixtranslator = { 1, 2, 3, 4; 'a','b','c','d'; 'A','B','C','D'};
handles.metricdata.settings.clearvars=1; %0=leave variables in workspace 1=clear unnecessary routine variables after script is done; helpful for debugging
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%popupmenu2_Callback(hObject, eventdata, handles);
if strcmp(handles.metricdata.settings.structuretype, 'line')
    se90 = strel('line', handles.metricdata.settings.disksize, 90);
    se0 = strel('line', handles.metricdata.settings.disksize, 0);
    handles.metricdata.settings.structure=[se0 se90];
else
    handles.metricdata.settings.structure=strel(handles.metricdata.settings.structuretype,handles.metricdata.settings.disksize);
end
handles.metricdata.settings.structure2=strel(handles.metricdata.settings.structuretype2,handles.metricdata.settings.disksize2);

if handles.metricdata.settings.thresholdmode==1
    %%%settings.thresholdmode=1;
    handles.metricdata.settings.thresholdvalue.dilate=1;
    handles.metricdata.settings=ptc(handles.metricdata.settings);
    set(handles.edit3, 'String', handles.metricdata.settings.thresholdinterval.default);
    set(handles.edit4, 'String', handles.metricdata.settings.particlevariation.default);
    set(handles.checkbox6, 'Value', handles.metricdata.settings.thresholdvalue.dilate);
elseif handles.metricdata.settings.thresholdmode==2
    %%%settings.thresholdmode=2;
    handles.metricdata.settings=ptc(handles.metricdata.settings);
    set(handles.edit9, 'String', handles.metricdata.settings.canny.low)
    set(handles.edit10, 'String', handles.metricdata.settings.canny.high)
elseif handles.metricdata.settings.thresholdmode==3
    handles.metricdata.settings=ptc(handles.metricdata.settings);
    set(handles.edit2, 'String', handles.metricdata.settings.sobel.threshold);
elseif handles.metricdata.settings.thresholdmode==4
    handles.metricdata.settings=ptc(handles.metricdata.settings);
    set(handles.edit11, 'String', handles.metricdata.settings.thresholdpixelvalue);
else
    error('Threshold method not supported. Exiting...');
end
set(handles.text20,'String','Done/Ready');
guidata(hObject, handles);

%display(['thresholdmode: ' num2str(handles.metricdata.settings.thresholdmode)]);
%display(['canny low: ' num2str(settings.canny.low)]);
assignin('base', 'settings', handles.metricdata.settings);
%save('data.mat');
disp('Done!');


% --- Executes on button press in radiobutton3.
function radiobutton3_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton3
