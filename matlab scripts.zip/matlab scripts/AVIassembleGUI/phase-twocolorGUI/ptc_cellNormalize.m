function results = ptc_cellNormalize(rc,fp1, returncellmask)

settings.padding = 5;
settings.mincellwidth=5;
settings.maxcellwidth=25;
settings.mincelllength=5;
settings.maxcelllength=100;
settings.normalcellrows = 30; %default 30
settings.normalcellcolumns = 100; %default 100
%create phase mask matrix
imagerc=zeros(size(fp1,1),size(fp1,2));
unit_cell = zeros(settings.normalcellrows,settings.normalcellcolumns);
for i=1: uint8(settings.normalcellcolumns / 2)
    for j = 1:settings.normalcellrows
        unit_cell(j,i) = 1000;
    end
end

for i=1:length(rc)
    imagerc(rc(i,1),rc(i,2))=1;
end


if (min(rc(:,1)) > 5) && (min(rc(:,2)) > 5) && (max(rc(:,1)) < (size(fp1,1)-5)) && (max(rc(:,2)) < (size(fp1,2)-5))
    %edge detection padding
    imagerc=imagerc( min(rc(:,1))-settings.padding:max(rc(:,1))+settings.padding, min(rc(:,2))-settings.padding:max(rc(:,2))+settings.padding);
    %create fluorescent image
    imagep1=fp1(min(rc(:,1))-settings.padding:max(rc(:,1))+settings.padding, min(rc(:,2))-settings.padding:max(rc(:,2))+settings.padding);
    
    %Get dimensions
    imagerc_props=regionprops(imagerc,'Centroid','MajorAxisLength','MinorAxisLength','Orientation','Area','Extent');
    
    
    %this conditional is new
    if (imagerc_props.MinorAxisLength < settings.mincellwidth) || (imagerc_props.MinorAxisLength > settings.maxcellwidth) || (imagerc_props.MajorAxisLength < settings.mincelllength) || (imagerc_props.MajorAxisLength > settings.maxcelllength)
        display('cell rejected');
        results={NaN NaN NaN};
    else
        %copy of raw mask for output
        imagerc_raw = imagerc;
        
        %rotate mask and fluorescence
        imagerc = imrotate(imagerc, -imagerc_props.Orientation);
        imagep1 = imrotate(imagep1, -imagerc_props.Orientation);
        
        %Experimental Feature: trim zeros from mask, crop fluorescence image to match
        
        %re-take regionprops of mask
        %imagerc_props=regionprops(imagerc,'Centroid','MajorAxisLength','MinorAxisLength','Orientation');
        %imagerc = imcrop(imagerc, [imagerc_props.Centroid(1) - (imagerc_props.MajorAxisLength / 2), imagerc_props.Centroid(2) - (imagerc_props.MinorAxisLength / 2), imagerc_props.MajorAxisLength, imagerc_props.MinorAxisLength]);
        %imagep1 = imcrop(imagep1, [imagerc_props.Centroid(1) - (imagerc_props.MajorAxisLength / 2), imagerc_props.Centroid(2) - (imagerc_props.MinorAxisLength / 2), imagerc_props.MajorAxisLength, imagerc_props.MinorAxisLength]);
        
        %End of experimental feature
        
        
        %resize to unit size
        imagerc = imresize(imagerc, [settings.normalcellrows,settings.normalcellcolumns]);
        imagep1 = imresize(imagep1, [settings.normalcellrows,settings.normalcellcolumns]);
        
        %%%%%%%%%%%%%%%%%%%
        %Check orientation%
        %%%%%%%%%%%%%%%%%%%
        
        %make the data matrix
        vector_lcv = 1;
        
        %create a flipped copy of original image
        imagep1_flipped = flip(imagep1,2);
        
        %create a 1 row data vector for each image
        image_vector = [1, (size(imagep1,1)*size(imagep1,2))];
        image_vector_flipped = [1, (size(imagep1,1)*size(imagep1,2))];
        unit_image_vector = [1, (size(imagep1,1)*size(imagep1,2))];
        
        vector_lcv = 1;
        for i = 1:size(imagep1,1)
            for j = 1:size(imagep1,2)
                image_vector(1,vector_lcv) = imagep1(i,j);
                unit_image_vector(1,vector_lcv) = unit_cell(i,j);
                image_vector_flipped(1,vector_lcv) = imagep1_flipped(i,j);
                vector_lcv = vector_lcv + 1;
            end
        end
        
        covMat1 = cov(image_vector, unit_image_vector);
        covMat2 = cov(image_vector_flipped, unit_image_vector);
        
        if abs(covMat1(1,2)) <= abs(covMat2(1,2))
            
        else
            imagep1 = imagep1_flipped;
        end
        
        %check images manually
        %         imshow(imagerc);
        %         pause(0.5);
        %         imagep1_mask=uint16(imagerc).*imagep1;
        %         imshow(imagep1_mask);
        %         pause(0.5);
        
        if returncellmask == 0
            results = imagep1;
        else
            results = [imagep1 {imagerc} {imagerc_raw}];
        end
    end
    
    
    
    
    
    
end





end

