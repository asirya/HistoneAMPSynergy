%finds maximum in fluorescence channel, determines distance from centroid,
%fits pixels around maximum to gaussian
%returns results(1)= distance from centroid, results(2)=fitted gaussian peak intensity / avg cell intensity
%
%Albert Siryaporn
%2013-07-30

%2018-05-03 Henry: added to results output

function results=ptc_localization(rc, fp1)


settings.showimage=0;
settings.showpositions=0;
settings.showmax=0;
settings.plotfits=0;

settings.assigninbase=0;
settings.padding=5;
settings.maxcelllength=150;


imagerc=zeros(size(fp1,1),size(fp1,2));
for i=1:length(rc)
    imagerc(rc(i,1),rc(i,2))=1;
end

if (min(rc(:,1)) > 5) && (min(rc(:,2)) > 5) && (max(rc(:,1)) < (size(fp1,1)-5)) && (max(rc(:,2)) < (size(fp1,2)-5))
    imagerc=imagerc( min(rc(:,1))-settings.padding:max(rc(:,1))+settings.padding,...
        min(rc(:,2))-settings.padding:max(rc(:,2))+settings.padding);
    
    imagep1=fp1( min(rc(:,1))-settings.padding:max(rc(:,1))+settings.padding,...
        min(rc(:,2))-settings.padding:max(rc(:,2))+settings.padding);
    
    imagep1_mask=uint16(imagerc).*imagep1;
    
    imagerc_props=regionprops(imagerc,'Centroid','MajorAxisLength','MinorAxisLength','Orientation','Area','Extent');
    
    if settings.assigninbase
        assignin('base', 'rc', rc);
        assignin('base', 'imagerc', imagerc);
        assignin('base', 'imagep1', imagep1);
        assignin('base', 'settings_localization', settings);
        assignin('base', 'imagerc_props', imagerc_props);
    end
    
    if imagerc_props.MajorAxisLength < settings.maxcelllength %make sure cell isn't too long (chain of cells, etc).

        %find maximum
        [immax{2}, immax{1}]=find(imagep1==max(max(imagep1)));
        
        if imagerc(immax{2}(1,1), immax{1}(1,1)) %if cells are dense you can get a maximum from a different cell. don't analyze those cells
    
            %figure;
            %imshow(imagep1_mask,[]);
            cellavgintensity=sum(sum(imagep1_mask)) / imagerc_props.Area;
            
            %fit maximum in 5x5 pixel array
            %background-subtract the intensities
            intensity=[0; 1; 1.41; 2; 2.23; 2.82];
            intensity(1,2)=imagep1(immax{2}(1,1),immax{1}(1,1));
            intensity(2,2)=1/4* (   imagep1(immax{2}(1,1)+1,immax{1}(1,1))+...
                imagep1(immax{2}(1,1)-1,immax{1}(1,1))+...
                imagep1(immax{2}(1,1),immax{1}(1,1)+1)+...
                imagep1(immax{2}(1,1),immax{1}(1,1)-1));
            intensity(3,2)=1/4* (   imagep1(immax{2}(1,1)+1,immax{1}(1,1)+1)+...
                imagep1(immax{2}(1,1)+1,immax{1}(1,1)-1)+...
                imagep1(immax{2}(1,1)-1,immax{1}(1,1)+1)+...
                imagep1(immax{2}(1,1)-1,immax{1}(1,1)-1));
            intensity(4,2)=1/4* (   imagep1(immax{2}(1,1)+2,immax{1}(1,1))+...
                imagep1(immax{2}(1,1)-2,immax{1}(1,1))+...
                imagep1(immax{2}(1,1),immax{1}(1,1)+2)+...
                imagep1(immax{2}(1,1),immax{1}(1,1)-2));
            intensity(5,2)=1/8* (   imagep1(immax{2}(1,1)+1,immax{1}(1,1)+2)+...
                imagep1(immax{2}(1,1)+1,immax{1}(1,1)-2)+...
                imagep1(immax{2}(1,1)+2,immax{1}(1,1)+1)+...
                imagep1(immax{2}(1,1)+2,immax{1}(1,1)-1)+...
                imagep1(immax{2}(1,1)-1,immax{1}(1,1)+2)+...
                imagep1(immax{2}(1,1)-1,immax{1}(1,1)-2)+...
                imagep1(immax{2}(1,1)-2,immax{1}(1,1)+1)+...
                imagep1(immax{2}(1,1)-2,immax{1}(1,1)-1));
            intensity(6,2)=1/4* (   imagep1(immax{2}(1,1)+2,immax{1}(1,1)+2)+...
                imagep1(immax{2}(1,1)+2,immax{1}(1,1)-2)+...
                imagep1(immax{2}(1,1)-2,immax{1}(1,1)+2)+...
                imagep1(immax{2}(1,1)-2,immax{1}(1,1)-2));
            
            %fitoptions
            StartPoint=[imagep1(immax{2}(1,1), immax{1}(1,1)) 0 0];
            Upperbound=[2*imagep1(immax{2}(1,1), immax{1}(1,1)) 5 5];
            Lowerbound=[-Inf -1 0.0001];
            %imfitoptions=fitoptions('gauss1', 'StartPoint', StartPoint, 'Upper', Upperbound);
                     
            %fit, get coefficients    
            [immaxfit, fitgoodness]=fit(intensity(:,1), intensity(:,2), 'gauss1','Lower',Lowerbound);
            fitcoefficients=coeffvalues(immaxfit);
            a=fitcoefficients(1);
            b=fitcoefficients(2);
            c=fitcoefficients(3);
            intensity(:,3)=[mygauss(a,b,c,0); mygauss(a,b,c,1); mygauss(a,b,c,1.41); mygauss(a,b,c,2); mygauss(a,b,c,2.23); mygauss(a,b,c,2.82)];
                       
            %statistics and output
            dfromcentroid=((immax{1}(1,1)-imagerc_props.Centroid(1))^2+(immax{2}(1,1)-imagerc_props.Centroid(2))^2)^0.5 / (0.5*imagerc_props.MajorAxisLength);
            peaktobackground=fitcoefficients(1)/cellavgintensity;
            stdevtobackground=std2(imagep1_mask)/cellavgintensity;
            %changed by henry
            %original line:
            %results=[peaktobackground stdevtobackground dfromcentroid];
            results=[peaktobackground stdevtobackground dfromcentroid a b c];
            %end of changes
            
            if settings.showimage
                display('new cell');
                display(['peaktobackground: ' num2str(peaktobackground) ' stdevtobackground: ' num2str(stdevtobackground) ' unit distance from centroid: ' num2str(dfromcentroid) ' cell length: ' num2str(imagerc_props.MajorAxisLength)]);
                display(['fit results a: ' num2str(a) ' b: ' num2str(b) ' c: ' num2str(c)]);
                
                %pause on
                window_localization=figure;
                imshow(imagep1,[]);
              
                if settings.showpositions
                    %create coordinate system
                    x_pt(1)=imagerc_props.Centroid(1)-0.4*imagerc_props.MajorAxisLength*cosd((imagerc_props.Orientation));
                    y_pt(1)=imagerc_props.Centroid(2)+0.4*imagerc_props.MajorAxisLength*sind((imagerc_props.Orientation));
                    x_pt(2)=imagerc_props.Centroid(1)+0.4*imagerc_props.MajorAxisLength*cosd((imagerc_props.Orientation));
                    y_pt(2)=imagerc_props.Centroid(2)-0.4*imagerc_props.MajorAxisLength*sind((imagerc_props.Orientation));
                    
                    hold on
                    plot(imagerc_props.Centroid(1), imagerc_props.Centroid(2),'Color', 'r', 'LineWidth',3);
                    plot(x_pt(1),y_pt(1),'Color', 'b', 'LineWidth',3);
                    plot(x_pt(2),y_pt(2),'Color', 'y', 'LineWidth',3);
                    line(x_pt, y_pt, 'Color', 'r', 'LineWidth',1);
                end
                
                if settings.showmax
                    hold on
                    plot(immax{1}(1,1), immax{2}(1,1), 'Color', 'r', 'LineWidth',3);
                end
                
                pause(0.5)
                close(window_localization);
                
                if settings.plotfits
                    window_plot=figure();
                    figure(window_plot);
                    plot(intensity(:,1), intensity(:,2),'Color','b');
                    hold on
                    plot(intensity(:,1), intensity(:,3),'Color','r');
                    pause(0.5);
                    close(window_plot);
                end
            end
        else
            display('maximum pixel is outside of cell boundary');
            results=[NaN NaN NaN];
        end
    else
        display('greater than outside of cell length restriction');
        results=[NaN NaN NaN];
    end
else
    display('cell out of bounds');
    results=[NaN NaN NaN];
end