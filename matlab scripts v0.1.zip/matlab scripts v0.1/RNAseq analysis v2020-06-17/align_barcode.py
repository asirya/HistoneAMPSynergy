#!/usr/bin/env python
#align_barcode.py
#parses fastq files from illumina reader
#assumes that:  barcodes are in read2.fastq
#               sequences are in read1.fastq
#               read1 and read2 are aligned
#
#separates out based on barcodes
#usage: align_barcode.py BARCODE barcodereads(read2).fastq sequencereads(read1).fastq
#
#Albert Siryaporn
#2015-09-02

import re
import sys

if len(sys.argv) == 4:
    barcode= sys.argv[1]
    filename1= sys.argv[2]
    filename2= sys.argv[3]
else:
    print("Usage: ffilter_barcode.py BARCODE barcodereads.fastq sequencereads.fastq")
    sys.exit(2)

from Bio import SeqIO

records1=SeqIO.parse(filename1, "fastq")
records2=SeqIO.parse(filename2, "fastq")

for record1 in records1:
    record2 = records2.next()
    matchobj = re.match(barcode, str(record1.seq))
    if matchobj:
        if record1.id == record2.id:
            print record2.format("fastq")
    if record1.id != record2.id:
        print "ERROR: INDEXING ERROR"
        print >> sys.stderr, "ERROR: INDEXING ERROR"