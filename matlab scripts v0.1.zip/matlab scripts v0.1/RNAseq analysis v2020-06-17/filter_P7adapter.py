#!/usr/bin/env python
#usage: filter_P7adapter.py FILENAME.fastq
#requires: BioPython
#parses fastq files that have already been aligned with multiplex index (BARCODE not present in this sequence)
#searches for P7 adapter sequence and trims it out
#spits back trimmed text and unmodified sequences that don't contain P7 adapter
#
#Albert Siryaporn
#2015-09-08


#from __future__ import print_function
import re
import sys

#######################
####    SETTINGS   ####
#######################
minsize=10
P7adapterseq='GATCGGAAGA'
#######################

if len(sys.argv) == 2:
    filename= sys.argv[1]
else:
    print("Usage: filter_P7adapter.py FILENAME.fastq")
    sys.exit(2)

newfilename=re.subn(re.compile('.fastq',re.IGNORECASE),'_P7.fastq',filename)
newlogfilename=re.subn(re.compile('.fastq',re.IGNORECASE),'_P7stats.txt',filename)
if newfilename[1] > 0:
    print "Saving file to",newfilename[0]
    file=open(newfilename[0],'w')
    logfile=open(newlogfilename[0],'w')
else:
    sys.exit("Filename must have .sam extension")

from Bio import SeqIO
my_regex= "^" + "(\w*)" + re.escape(P7adapterseq)
belowminsize=0
match=0
nomatch=0

for idx, seq_record in enumerate(SeqIO.parse(filename, "fastq"), start=0):
    matchobj = re.search(my_regex, str(seq_record.seq),re.IGNORECASE)
    if matchobj:
        if len(matchobj.group(1)) >= minsize:
            startpos = matchobj.start()
            endpos = matchobj.start()+len(matchobj.group(1))
            trimmed_record = seq_record[startpos:endpos]
            #            print seq_record.format("fastq")
            #print trimmed_record.format("fastq")
            file.write(trimmed_record.format("fastq"))
            match +=1
        else:
            belowminsize += 1
    else:
        nomatch += 1
        #print seq_record.format("fastq")
        file.write(seq_record.format("fastq"))

file.close
print "Saved to",newfilename[0],". Filtering done."

string='Number of sequences: ' + str(idx) + '\n\tP7adapter matched: ' + str(match) + ' (' + str(int(float(match)/float(idx)*100)) + '%)' + '\n\t\tmatched but below min. size (' + str(minsize) + '): ' + str(belowminsize) + ' (' + str(int(float(belowminsize)/float(idx)*100)) + '%)'+ '\n\tP7 not matched: ' + str(nomatch) + ' (' + str(int(float(nomatch)/float(idx)*100)) + '%)'
logfile.write(string)
logfile.close
print >> sys.stderr, string