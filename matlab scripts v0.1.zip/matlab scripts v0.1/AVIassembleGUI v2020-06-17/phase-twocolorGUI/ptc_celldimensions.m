%finds axis lengths for each cell
%
%Albert Siryaporn
%2013-08-13
%2018-11-16: v1.3: Henry added perimeter, solidity to output. Made a stability
%change in impage1_combined


function results=ptc_celldimensions(rc,phase)


settings.showimage=0;
settings.showpositions=0;
settings.showmax=0;
settings.plotfits=0;
settings.maxcelllength = 100; %default 100
settings.mincelllength=5; %default 20
settings.mincellwidth=5; %default 20
settings.maxcellwidth= 25; %default 25
settings.assigninbase=0;
settings.padding=5;


%Henry commented these out
% settings.mincellarea=250;
% settings.maxcellarea=1500;
%End of change

imagerc=zeros(size(phase,1),size(phase,2));
for i=1:length(rc)
    imagerc(rc(i,1),rc(i,2))=1;
end

if (min(rc(:,1)) > 5) && (min(rc(:,2)) > 5) && (max(rc(:,1)) < (size(phase,1)-5)) && (max(rc(:,2)) < (size(phase,2)-5))
    imagerc=imagerc( min(rc(:,1))-settings.padding:max(rc(:,1))+settings.padding,...
        min(rc(:,2))-settings.padding:max(rc(:,2))+settings.padding);
    
    imagep1=phase( min(rc(:,1))-settings.padding:max(rc(:,1))+settings.padding,...
        min(rc(:,2))-settings.padding:max(rc(:,2))+settings.padding);
   
    
    %Henry Change
    %Old Line
    %imagerc_props=regionprops(imagerc,'Centroid','MajorAxisLength','MinorAxisLength','Orientation','Area','Extent');
    %New Line
    imagerc_props=regionprops(imagerc,'Centroid','MajorAxisLength','MinorAxisLength','Orientation','Area','Extent', 'Perimeter', 'Solidity');
    %End of changes
    
    if settings.assigninbase
        assignin('base', 'rc', rc);
        assignin('base', 'imagerc', imagerc);
        assignin('base', 'imagep1', imagep1);
        assignin('base', 'settings_localization', settings);
    end
    
    
    %Changed by Henry
    %Original Line
    %imagep1_combined=imagerc.*imagep1;
    
    %New Line Moved to settings.assigninbase
    %end of changes
    
    if settings.assigninbase
        imagep1_combined=uint16(imagerc).*imagep1;
        assignin('base', 'imagep1_combined', imagep1_combined);
        assignin('base', 'imagerc_props', imagerc_props);
    end
    
    
    %Henry Change:
    %this chunk was pretty reduntant. Dialog box was already commented out,
    %used to just check for cell length, width and area, using string
    %'sastisfied' to pass result.
    
    %Old Lines
%     if (imagerc_props.MinorAxisLength < settings.mincellwidth) || (imagerc_props.MinorAxisLength > settings.maxcellwidth) || ...
%             (imagerc_props.MajorAxisLength < settings.mincelllength) || (imagerc_props.MajorAxisLength > settings.maxcelllength)
%             %|| (imagerc_props.Area < settings.mincellarea) || (imagerc_props.Area > settings.maxcellarea)
%         %imshow(imagep1_combined,[]);
%         %satisfied=questdlg('Accept the rectange? ', 'Dialog', 'Yes', 'No', 'No');
%         satisfied='No';
%     else
%         if settings.showimage
%             imshow(imagep1_combined,[]);
%             pause(0.05);
%         end
%         satisfied='Yes';
%     end
%     
%     if strcmp(satisfied, 'Yes')
%         results=[imagerc_props.Area imagerc_props.MinorAxisLength imagerc_props.MajorAxisLength];
%     else
%         display('cell rejected');
%         results=[NaN NaN NaN];
%     end

    %New Lines
    if (imagerc_props.MinorAxisLength < settings.mincellwidth) || (imagerc_props.MinorAxisLength > settings.maxcellwidth) || (imagerc_props.MajorAxisLength < settings.mincelllength) || (imagerc_props.MajorAxisLength > settings.maxcelllength)
        display('cell rejected');
        results=[NaN NaN NaN];
    else
        results=[imagerc_props.Area imagerc_props.MinorAxisLength imagerc_props.MajorAxisLength imagerc_props.Perimeter imagerc_props.Solidity];
    end
    
    %End of changes
    
else
    display('cell out of bounds');
    results=[NaN NaN NaN];
end