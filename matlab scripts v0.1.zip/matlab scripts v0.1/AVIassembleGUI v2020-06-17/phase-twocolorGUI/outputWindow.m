function varargout = outputWindow(varargin)
%OUTPUTWINDOW MATLAB code file for outputWindow.fig
%2018-05-02 Created by Henry for data visualization.

% Begin initialization code - DO NOT EDIT
gui_Singleton = 0;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @outputWindow_OpeningFcn, ...
                   'gui_OutputFcn',  @outputWindow_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before outputWindow is made visible.
function outputWindow_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   unrecognized PropertyName/PropertyValue pairs from the
%            command line (see VARARGIN)

% Choose default command line output for outputWindow
handles.output = hObject;
handles.myResults = varargin{1};
handles.myLocalResults = varargin{2};
handles.myPictures = varargin{3};
handles.myNames = varargin{4};
imshow(handles.myPictures{1},'Parent', handles.axes1,'DisplayRange',[]);
myDomain = (-50:50);
handles.myChart = plot(myDomain, handles.myResults(1,6) * exp(-((myDomain - handles.myLocalResults(1,3))/handles.myLocalResults(1,4)).^2));
ylim([0 8]);
set(handles.listbox1, 'string', strcat('Cell Index:',{'  '}, num2str(handles.myResults(:,1))));
set(handles.lblAvg1, 'string', strcat('Average Cy5 / Area:',{'  '}, num2str(mean(handles.myResults(:,4)))));
set(handles.lblAvg2, 'string', strcat('Average Area:',{'  '}, num2str(mean(handles.myResults(:,3)))));
set(handles.lblAvg3, 'string', strcat('Number of Cells:',{'  '}, num2str(length(handles.myResults(:,1)))));
set(handles.lblAvg4, 'string', strcat('Average Width:',{'  '}, num2str(mean(handles.myLocalResults(:,4)))));
set(handles.lblAvg5, 'string', strcat('Average Pk2Bkg:',{'  '}, num2str(mean(handles.myResults(:,6)))));
set(handles.lblAvg6, 'string', strcat('Average Amplitude:',{'  '}, num2str(mean(handles.myResults(:,2)))));
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes outputWindow wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = outputWindow_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
k = get(handles.listbox1,'value');
set(handles.lblCell1, 'string', strcat('Cy5:',{'  '}, num2str(handles.myResults(k,2))));
set(handles.lblCell2, 'string', strcat('Pixel Area:',{'  '}, num2str(handles.myResults(k,3))));
set(handles.lblCell3, 'string', strcat('Cy5 / Area:', {'  '}, num2str(handles.myResults(k,4))));
set(handles.lblCell4, 'string', strcat('PeakToBackground:',{'  '}, num2str(handles.myResults(k,6))));
set(handles.lblCell5, 'string', strcat('StdToBackground:',{'  '}, num2str(handles.myResults(k,7))));
set(handles.lblCell6, 'string', strcat('Distance From Centroid:',{'  '}, num2str(handles.myResults(k,8))));
set(handles.lblCell8, 'string', strcat('Fit Amplitude:',{'  '}, num2str(handles.myLocalResults(k,2))));
set(handles.lblCell9, 'string', strcat('Fit Para. b:',{'  '}, num2str(handles.myLocalResults(k,3))));
set(handles.lblCell10, 'string', strcat('Fit FWHM:',{'  '}, num2str(handles.myLocalResults(k,4))));
set(handles.lblCell11, 'string', strcat('File Name:',{'  '}, handles.myNames(k,1)));
set(handles.lblCell12, 'string', strcat('x:',{'  '}, num2str(handles.myLocalResults(k,6))));
set(handles.lblCell13, 'string', strcat('y:',{'  '}, num2str(handles.myLocalResults(k,7))));
myDomain = (-50:50);
handles.myChart = plot(myDomain, handles.myResults(k,6) * exp(-((myDomain - handles.myLocalResults(k,3))/handles.myLocalResults(k,4)).^2));
ylim([0 8]);
imshow(handles.myPictures{k},'Parent', handles.axes1,'DisplayRange',[]);
% Hints: contents = cellstr(get(hObject,'String')) returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

index_selected = get(handles.listbox1,'value');
