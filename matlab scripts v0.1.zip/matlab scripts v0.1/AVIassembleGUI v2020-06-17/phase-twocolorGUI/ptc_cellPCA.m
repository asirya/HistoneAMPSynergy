function results = ptc_cellPCA(rc)

%%%%%%%%
%PCA
%%%%%%%%

%Create Data Matrix
vector_lcv = 1;

image_vector = [size(rc,1), (size(rc{1},1)*size(rc{1},2))];
for i = 1:size(rc,1)
    vector_lcv = 1;
    for j = 1:size(rc{1},1)
        for k = 1:size(rc{1},2)
            image_vector(i,vector_lcv) = rc{i}(j,k);
            vector_lcv = vector_lcv + 1;
        end
    end
end

%demean
image_vector = bsxfun(@minus,image_vector,mean(image_vector));

%Do PCA
[coeff,score,latent] = pca(image_vector);

% Calculate eigenvalues and eigenvectors of the covariance matrix
covarianceMatrix = cov(image_vector);
[V,D] = eig(covarianceMatrix);

%Plot
% figure()
% plot(score(:,1),score(:,2),'+')
% xlabel('1st Principal Component')
% ylabel('2nd Principal Component')

x1 = score(:,1);
y1 = score(:,2);

assignin('base','PCScores', score);

% for i = 1:size(rc,1)
%     scatter(x1(i), y1(i), 15, rc{i,2}, 'filled');
%    
%     hold on;
% end

results = 1;
end

